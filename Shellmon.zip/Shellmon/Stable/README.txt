use the following steps

1. run the shellmon_client_preq.sh file to prepare your clinet 
2. make sure a mysql server is setup on your network and accepts remote access
3. run the Shellmon_server.py first provide MYSQL server IP and username, password 
3. run shellmon_client_RP_tuned.py in the raspbery provide MYSQL server IP and username, password