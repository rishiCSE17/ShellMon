import docker
import random
import paramiko
import os
import time
import datetime

client_docker = docker.from_env()

def append_log(info):
    time_stamp = time.time()
    date_stamp = str(datetime.datetime.fromtimestamp
                        (time_stamp).strftime
                                ('%Y-%m-%d %H:%M:%S')
                     )
    ip = os.popen(
            "a=`ifconfig ens33 | grep inet | head -1` ; "
            "echo $a | cut -d ' ' -f2"
    ).read().rstrip()

    '''
    NOTE : the ip & mac syntax is subject to change based on platform
    '''

    mac = os.popen(
            "a=`ifconfig ens33 | grep ether | head -1` ; "
            "echo $a | cut -d ' ' -f2 "
    ).read().rstrip()

    log_file = open('/tmp/migrate_log.csv','a')
    entry = '\n[ ' + str(date_stamp) + '] : , ' + ip + ' , ' + mac + ' , ' + info
    log_file.write(entry)
    log_file.close()

def transfer_cont():
    t_start = time.time()

    # assign victim container object
    cont = client_docker.containers.list()[0]

    # generate a image name
    img_name = 'img_'+cont.short_id + '_' +str(random.randint(1000, 9999)*131)

    # save the image into local image repo
    info = '[1/8] committing container ' + cont.short_id + ' ...'
    print(info)
    st_time=time.time()
    cont.commit(repository=img_name)
    append_log(info='done ' + info + ' , ' + str(time.time()-st_time))
    # assign the subjected image object
    img_obj= client_docker.images.get(img_name)

    # get raw file stream of the object
    img_data=img_obj.save()

    # save the image into /tmp dir using shell script
    cmd_save = 'docker save -o ' + '/tmp/' + img_name + '.img ' + img_name
    info='[2/8] saving image ' + img_name + '.img ...'
    print(info)
    st_time = time.time()
    os.system(cmd_save)
    append_log(info='done ' + info + ' , ' + str(time.time() - st_time))

    # details of the scp parameter
    root_pw='password'
    file_loc='/tmp/'+img_name+'.img'
    dst_uname='rishi'
    dst_pw='Password123..'
    dst_ip='172.20.21.16'

    # command to transfer the file
    cmd_transfer = "sshpass -p " + dst_pw + \
                   " scp -o StrictHostKeyChecking=no " + file_loc + " " +\
                   dst_uname + "@" + \
                   dst_ip + ":" +\
                   file_loc
    info='[3/8] transferring to ' + dst_ip + ' ...'
    print(info)
    st_time = time.time()
    os.system(cmd_transfer)
    append_log(info='done ' + info + ' , ' + str(time.time() - st_time))

    # remove the file from local FS
    info='[4/8] removing '+ file_loc + ' from local filesystem ...'
    print(info)
    st_time = time.time()
    os.system('rm '+file_loc)
    append_log(info='done ' + info + ' , ' + str(time.time() - st_time))

    ssh_client = paramiko.SSHClient()
    ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh_client.connect(hostname=dst_ip,
                       username=dst_uname,
                       password=dst_pw
                       )
    # load container to the local docker repo of remote platform
    info='[5/8] loading image to remote repo...'
    print(info)
    st_time = time.time()
    stdin, stdout, stderr = ssh_client.exec_command('docker load -i ' + file_loc)
    print('Acknowledgement... ')
    for line in stdout:
        print(line)
        append_log('ACK :' + line.rstrip())
    append_log(info='done ' + info + ' , ' + str(time.time() - st_time))

    # start container on remote platform
    info='[6/8] firing container demon...'
    print(info)
    st_time = time.time()
    stdin, stdout, stderr = ssh_client.exec_command('docker run -d ' + img_name)
    print('Acknowledgement... ')
    for line in stderr:
        print(line)
        append_log('ACK : ' + line.rstrip())
    append_log(info='done ' + info + ' , ' + str(time.time() - st_time))

    # kill container from local system
    info='[7/8] killing local conainer ' + cont.short_id + '...'
    print(info)
    st_time = time.time()
    os.system('docker kill ' + cont.short_id)
    append_log(info='done ' + info + ' , ' + str(time.time() - st_time))

    # remove stopped container from memory
    info='[8/8] removing container ' + cont.short_id + ' from local memory... '
    print(info)
    st_time = time.time()
    os.system('docker rm ' + cont.short_id)
    append_log(info='done ' + info + ' , ' + str(time.time() - st_time))

    info='job done in :  sec(s) ! --> , , ' + str(time.time() - t_start)
    print(info)
    append_log(info=info)

if __name__ == '__main__':
    transfer_cont()

