'''
DOCKER AGENT 

this script uses docker-python API and BASH to update docker information to a 
remote mysql database

information that gets updated
	[1] Image info
	[2] Container info
	[3] Process info running in a container 
update period 
	variable, set by 'update_freq'
'''


import docker
import pymysql
import socket
import os
import time

#update frequecy in secs
update_freq=5

# connection & cursor object for database
db_conn = None
db_cur = None

# docker client object to localhost
cl = docker.from_env()


# obtain the ip of the local computer
def getIP(intf):
    ip = os.popen("ifconfig " + intf + " | grep 'inet' | head -1 | cut -d ':' -f2 | cut -d ' ' -f1").read()
    return (ip.rstrip())


# connects the remote database database

'''
Note : to activate remote operation in mysql server
	* install : mysql-server
	* goto : /etc/mysql/mysql.conf.d/mysqld.cnf
	* set : bind-address = 0.0.0.0
	* run : $ sudo systemctl restart mysql.service 
'''
def db_connect(host, un, pw, db, port):
    global db_conn
    db_conn = pymysql.connect(host=host, port=port, db=db, user=un, passwd=pw)


'''
----------------------------Images-------------------------------------------------------------
'''

# delete previous entries before insert
def del_b4_insert_img(ip):
    global db_cur
    db_cur = db_conn.cursor()
    qstr = "delete from images_tab " \
           "where server_ip='" + ip + "'"
    db_cur.execute(qstr)
    db_conn.commit()


# insert new entries
def insert_images(ip, id, tag):
    global db_cur
    qstr = "insert into images_tab " \
           "values('" + ip + "','" + id + "','" + tag + "')"
    db_cur.execute(qstr)
    db_conn.commit()


# obtains image information using docker API
def update_images_tab(intf):
    ip = '136.148.94.219'#getIP(intf)
    print(ip)
    del_b4_insert_img(ip)
    for i in cl.images.list():
        id = i.short_id
        if (len(i.tags) == 0):
            tag = 'noName'
        else:
            tag = i.tags[0]
        insert_images(ip, id, tag)

'''
-----------------------------------------Containers----------------------------------------------
'''


def del_b4_insert_cont(ip):
    global db_cur
    db_cur = db_conn.cursor()
    qstr = "delete from containers_tab " \
           "where server_ip='" + ip + "'"
    db_cur.execute(qstr)
    db_conn.commit()


def insert_containers(srv_ip, img_id, cont_id, cont_name, cont_status, cont_ip, cont_util):
    global db_cur
    qstr="insert into containers_tab values ('"+\
                    srv_ip +"','"+ \
                    img_id +"','"+ \
                    cont_id +"','"+ \
                    cont_name +"', '"+ \
                    cont_status +"','"+ \
                    cont_ip +"',"+ \
                    str(cont_util) +\
         	")"
    db_cur.execute(qstr)
    db_conn.commit()

def get_cont_ip(cont_id):
    cmd="docker inspect --format='{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' " + str(cont_id)
    return os.popen(cmd).read().rstrip()

def update_container_tab(intf):
    ip = '136.148.94.219'#getIP(intf)
    del_b4_insert_cont(ip)
    for c in cl.containers.list(all=True):
        cont_id = c.short_id
        image_id = c.image.short_id
        cont_name = c.name
        cont_status = c.status
        cont_ip = get_cont_ip(cont_id)
        if cont_ip == '':
            cont_ip = 'n/a'
        insert_containers(ip, image_id , cont_id, cont_name, cont_status, cont_ip,100)

'''------------------------------------------------------------------------------------------------'''

# the infinite loop
def iterator(intf):
    while (True):
        update_images_tab(intf)
        update_container_tab(intf)
        time.sleep(update_freq)


# who initiates the process
def main():
    intf = 'eth0'  # input('Enter interface name : ')
    print(intf)
    db_connect('136.148.94.219', 'rishi', 'password', 'flow_schema', 3306)
    iterator(intf)


# from where every thing starts
main()
