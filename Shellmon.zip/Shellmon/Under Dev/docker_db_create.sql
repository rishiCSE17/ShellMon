create table flow_schema.images_tab(
    erver_ip varchar(20),
    image_id varchar(50),
    tags varchar(50)
);

create table flow_schema.containers_tab(
    server_ip varchar(20),
    iamge_id varchar(50),
    cont_id varchar(50),
    cont_name varchar(50),
    cont_status varchar(50),
    cont_ip varchar(50),
    cont_util double
);

create table flow_schema.tasks_tab(
    container_id varchar(50),
    uid varchar(50),
    pid varchar(10),
    ppid varchar(10),
    c varchar(10),
    stime varchar(20),
    tty varchar(20),
    _time varchar(20),
    cmd varchar(50)
);







